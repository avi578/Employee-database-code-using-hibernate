package com.tka.may3_criteria;

public class EmpAppSystem {

	public static void main(String[] args) {
		employeeoperation_HB eop=new employeeoperation_HB();
//		eop.getEmployeeById(101);
		//eop.getAllEmployee();
		//eop.getEmployeeByName("avi");
		eop.getEmployeeListWhoseNameStartsWith("dev");
		//eop.getEmployeeNameAndSalary();
		//eop.getMaxSalary();
		//eop.getSalaryBetweenGivenRange(Start,End);
		//eop.getEmployeeListByRole("Dev" or "Tester");
		//eop.getEmployeeListByRoleAndSalary(role,salary);
		//eop.getTotalSalaryOfGivanRole(role);
		//getEmployeeByDepartment(department name);
		//getEmployeeByExperience(minExperience,maxExperience);
		//getEmployeeJoinedAfterDate(date);
		//getEmployeeWithHighestSalary();
		//getEmployeeSortedBySalary(order);
		//getHighestPaidEmployee();
		//getLowestPaidEmployee();
		//getAverageSalaryOfDepartment(Department name);
		//getEmployeeByProject(ProjectName);
		//getTotalNumberOfEmployees();
		//getEmployeeDetailsById(id);
		//getEmployeeByLocation(location);
		//getEmployeeBySkillSet(skillset);
		//getEmployeeOnLeaveBetween(Start Date,End Date);
		//getSalaryDistributionByDepartment(department name);
		//getEmployeeCountByRole(role);
		//getRecentHires(limit);
		//getEmployeeByAgeRange(minAge,maxAge);
	}

}
