package com.tka.may3_criteria;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.AggregateProjection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.NativeQuery;

import com.tka.may1.employee;


public class employeeoperation_HB {
	SessionFactory sessionFactory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();
	Session openSession = sessionFactory.openSession();
	public void getEmployeeById(int empId) {
		employee emp=(employee)openSession.get(employee.class,empId);
		System.out.println(emp);
			
		
	}
	public void getEmployeeByName(String nm) {
		Criteria criteria = openSession.createCriteria(employee.class);
		 criteria.add(Restrictions.eq("name", nm));
		 criteria.add(Restrictions.eq("role", "hr"));
		List<employee> listEmployee=criteria.list();
		for(employee e:listEmployee) {
			System.out.println(e);
		}
	}
	public void getEmployeeNameAndSalary() {
		Criteria criteria = openSession.createCriteria(employee.class);
		PropertyProjection p1 = Projections.property("name");
		PropertyProjection p2 = Projections.property("salary");
		ProjectionList projectionList = Projections.projectionList();
		projectionList.add(p1);
		projectionList.add(p2);
		criteria.setProjection(projectionList);
		List<Object []> listEmployee=criteria.list();
		for(Object row[]:listEmployee) {
			for(Object col:row) {
				System.out.print(col+"--");
			}
			System.out.println();
		}
	}
	public void getAllEmployee() {
		Criteria criteria = openSession.createCriteria(employee.class);
		List<employee> listEmployee=criteria.list();
		for(employee e:listEmployee) {
			System.out.println(e);
		}
	}
	public void getEmployeeListWhoseNameStartsWith(String nm) {
		Criteria criteria = openSession.createCriteria(employee.class);
		criteria.add(Restrictions.like("role", nm));
		
		List<employee> listEmployee=criteria.list();
		for(employee e:listEmployee) {
			System.out.println(e);
		}
	}
	public void getMaxSalary() {
		Criteria criteria = openSession.createCriteria(employee.class);
		criteria.setProjection(Projections.max("salary"));
		List list = criteria.list();
		System.out.println(list);
		
	}
	
}
