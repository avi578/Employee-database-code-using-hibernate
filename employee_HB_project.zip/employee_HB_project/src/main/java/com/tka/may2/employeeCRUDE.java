package com.tka.may2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class employeeCRUDE {

	public void getEmployee() {
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		employee emp=(employee)openSession.get(employee.class,104);
		System.out.println(emp);
		
	}

	public void insertEmployee() {
		employee emp=new employee(102,"Saurabh","dev",50000);
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		openSession.save(emp);
		System.out.println("Employee inserted............");
		openSession.beginTransaction().commit();
	}

	public void updateEmployee() {
		employee emp=new employee();
		int empid=105;
		String name="akki";
		emp.setEid(empid);
		emp.setName(name);
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		employee empData=(employee)openSession.get(employee.class, empid);
		empData.setName(name);
		emp=empData;
		openSession.update(emp);
		System.out.println("Updated...........");
		openSession.beginTransaction().commit();
		
	}

	public void deleteEmployee() {
		employee emp=new employee();
		int empid=102;
		emp.setEid(empid);
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		openSession.delete(emp);
		System.out.println("deleted...........");
		openSession.beginTransaction().commit();
	}

}
