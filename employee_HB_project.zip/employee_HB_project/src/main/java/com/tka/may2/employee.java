package com.tka.may2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class employee {
	 public employee() {
		super();
	}
	public employee(int empid, String name, String role, double salary) {
		super();
		this.empid = empid;
		this.name = name;
		this.role = role;
		this.salary = salary;
	}
	@Id
	 @Column(name = "empid")
	int empid;
	String name;
	String role;
	double salary;
	public int getEid() {
		return empid;
	}
	public void setEid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + empid + ", name=" + name + ", role=" + role + ", salary=" + salary + "]";
	}
}
