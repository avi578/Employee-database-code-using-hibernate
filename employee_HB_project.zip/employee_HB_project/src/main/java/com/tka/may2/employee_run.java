package com.tka.may2;

import java.util.Scanner;

public class employee_run {
	public static void main(String[] args) {
		employeeCRUDE eCRUDE=new employeeCRUDE();
		int n;
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("Enter your choice:\n1:show data\n2:Insert\n3:Update\n4:Delete.\n5:Exit.");
			n=sc.nextInt();
			switch(n) {
			case 1:
				eCRUDE.getEmployee();
				break;
			case 2:
				eCRUDE.insertEmployee();
				break;
			case 3:
				eCRUDE.updateEmployee();
				break;
			case 4:
				eCRUDE.deleteEmployee();
				break;
			case 5:
				System.exit(n);
				break;
			}
		}while(n!=5);
	}
}
