package com.tka.may3_sql;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

import com.tka.may1.employee;


public class employeeoperation {
	SessionFactory sessionFactory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();
	Session openSession = sessionFactory.openSession();
	public void getEmployeeById(int empId) {
		employee emp=(employee)openSession.get(employee.class,empId);
		System.out.println(emp);
			
		
	}
	public void getEmployeeByName(String nm) {
		String query="select * from employee where name= '"+nm+"'";
		Query sqlQuery = openSession.createSQLQuery(query);
		List<Object []> listData=sqlQuery.list();
		for(Object [] row:listData) {
			for(Object col:row) {
				System.out.print(col+"\t");
			}
			System.out.println();
		}
	}
	public void getAllEmployee() {
		String query="select * from employee ";
		Query sqlQuery = openSession.createSQLQuery(query);
		List<Object []> listdata=sqlQuery.list();
		for(Object [] row : listdata) {
			for(Object col:row) {
				System.out.print(col+" ");
			}
			System.out.println();
		}
	}
	public void getEmployeeListWhoseNameStartsWith(String nm) {
		String query="select * from employee where name like '"+nm+"%'";
		Query sqlQuery = openSession.createSQLQuery(query);
		List<Object []> listData=sqlQuery.list();
		for(Object [] row:listData) {
			for(Object col:row) {
				System.out.print(col+"\t");
			}
			System.out.println();
		}
	}
}
