package com.tka.may3_sql;

public class EmpAppSystem {

	public static void main(String[] args) {
		employeeoperation eop=new employeeoperation();
//		eop.getEmployeeById(101);
//		eop.getAllEmployee();
//		eop.getEmployeeByName("avi");
		eop.getEmployeeListWhoseNameStartsWith("a");
	}

}
