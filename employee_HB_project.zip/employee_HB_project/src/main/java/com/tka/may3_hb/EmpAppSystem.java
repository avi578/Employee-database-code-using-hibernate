package com.tka.may3_hb;

public class EmpAppSystem {

	public static void main(String[] args) {
		employeeoperation_HB eop=new employeeoperation_HB();
//		eop.getEmployeeById(101);
		//eop.getAllEmployee();
		//eop.getEmployeeByName("avi");
		eop.getEmployeeListWhoseNameStartsWith("a");
	}

}
