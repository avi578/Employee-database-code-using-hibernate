package com.tka.may3_hb;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;

import com.tka.may1.employee;


public class employeeoperation_HB {
	SessionFactory sessionFactory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(employee.class).buildSessionFactory();
	Session openSession = sessionFactory.openSession();
	public void getEmployeeById(int empId) {
		employee emp=(employee)openSession.get(employee.class,empId);
		System.out.println(emp);
			
		
	}
	public void getEmployeeByName(String nm) {
		Query sqlQuery = openSession.createQuery("from employee where name='"+nm+"'");
		List<employee> listEmployee=sqlQuery.list();
		for(employee e:listEmployee) {
			System.out.println(e);
		}
	}
	public void getAllEmployee() {
		Query sqlQuery = openSession.createQuery("from employee");
		List<employee> listEmployee=sqlQuery.list();
		for(employee e:listEmployee) {
			System.out.println(e);
		}
	}
	public void getEmployeeListWhoseNameStartsWith(String nm) {
		String query="from employee where name like '"+nm+"%'";
		Query sqlQuery = openSession.createQuery(query);
		List<employee> listEmployee=sqlQuery.list();
		for(employee e:listEmployee) {
			System.out.println(e);
		}
	}
	
}
