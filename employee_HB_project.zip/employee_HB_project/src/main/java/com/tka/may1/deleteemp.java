package com.tka.may1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class deleteemp {
	public static void main(String[] args) {
		employee t1=new employee();
		t1.setEid(100);
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		openSession.delete(t1);
		System.out.println("deleted............");
		openSession.beginTransaction().commit();
	
	}
}
