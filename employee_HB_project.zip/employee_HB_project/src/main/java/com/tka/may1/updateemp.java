package com.tka.may1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class updateemp {
	public static void main(String[] args) {
		employee updateentry=new employee();
		int empid=101;
		String name="avi";
		updateentry.setEid(empid);
		updateentry.setName(name);
		
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		employee empdata=openSession.get(employee.class, 101);
		empdata.setName(name);
		updateentry=empdata;
		
		openSession.saveOrUpdate(updateentry);
		System.out.println("updated");
		openSession.beginTransaction().commit();
	
		
	}
}
