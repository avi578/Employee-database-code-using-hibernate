package com.tka.may1;




	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.cfg.Configuration;

	public class Printemployee {

		public static void main(String[] args) {
			//1 <hibernate-configuration>
			Configuration cfg = new Configuration();
			//hibernate-cfg.xml
			cfg.configure("hibernate.cfg.xml");
			//session factory
			cfg.addAnnotatedClass(employee.class);
			SessionFactory sessionFactory = cfg.buildSessionFactory();
			System.out.println("Hibernate configuration all done...");
			Session session = sessionFactory.openSession();
			employee emp=(employee)session.get(employee.class, 100);
			System.out.println(emp);
		}

	}

 