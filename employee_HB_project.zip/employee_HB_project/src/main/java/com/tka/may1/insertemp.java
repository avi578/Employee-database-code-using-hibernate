package com.tka.may1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class insertemp {
	public static void main(String[] args) {
		employee t1=new employee(104,"rutuja","hr",77000);
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		cfg.addAnnotatedClass(employee.class);
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session openSession = sessionFactory.openSession();
		openSession.save(t1);
		System.out.println("Inserted");
		openSession.beginTransaction().commit();
	
		
	}
}
