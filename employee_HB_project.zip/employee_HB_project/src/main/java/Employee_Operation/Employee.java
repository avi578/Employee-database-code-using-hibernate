package Employee_Operation;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Employee {
	@Id
	  long id;
	  String first_name;
	  String last_name;
	  String email;
	  String phone;
	  String gender;
	  LocalDate dob;
	  int age;
	  LocalDate joining_date;
	  double experience_years;
	  double salary;
	  String role;
	  String department;
	  String city;
	  String state;
	  String country;
	  String status;
	  LocalDate created_at;
	  LocalDate updated_at;
	  String skillset;
	public Employee() {
		super();
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return first_name;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.first_name = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return last_name;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.last_name = lastName;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the dob
	 */
	public LocalDate getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @return the joiningDate
	 */
	public LocalDate getJoiningDate() {
		return joining_date;
	}
	/**
	 * @param joiningDate the joiningDate to set
	 */
	public void setJoiningDate(LocalDate joiningDate) {
		this.joining_date = joiningDate;
	}
	/**
	 * @return the experienceYears
	 */
	public double getExperienceYears() {
		return experience_years;
	}
	/**
	 * @param experienceYears the experienceYears to set
	 */
	public void setExperienceYears(double experienceYears) {
		this.experience_years = experienceYears;
	}
	/**
	 * @return the salary
	 */
	public double getSalary() {
		return salary;
	}
	/**
	 * @param salary the salary to set
	 */
	public void setSalary(double salary) {
		this.salary = salary;
	}
	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the createdAt
	 */
	public LocalDate getCreatedAt() {
		return created_at;
	}
	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(LocalDate createdAt) {
		this.created_at = createdAt;
	}
	/**
	 * @return the updatedAt
	 */
	public LocalDate getUpdatedAt() {
		return updated_at;
	}
	/**
	 * @param updatedAt the updatedAt to set
	 */
	public void setUpdatedAt(LocalDate updatedAt) {
		this.updated_at = updatedAt;
	}
	
	/**
	 * @return the skillset
	 */
	public String getSkillset() {
		return skillset;
	}
	/**
	 * @param skillset the skillset to set
	 */
	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}
	public Employee(long id, String firstName, String lastName, String email, String phone, String gender,
			LocalDate dob, int age, LocalDate joiningDate, double experienceYears, double salary, String role,
			String department, String city, String state, String country, String status, LocalDate createdAt,
			LocalDate updatedAt,String skillset) {
		super();
		this.id = id;
		this.first_name = firstName;
		this.last_name = lastName;
		this.email = email;
		this.phone = phone;
		this.gender = gender;
		this.dob = dob;
		this.age = age;
		this.joining_date = joiningDate;
		this.experience_years = experienceYears;
		this.salary = salary;
		this.role = role;
		this.department = department;
		this.city = city;
		this.state = state;
		this.country = country;
		this.status = status;
		this.created_at = createdAt;
		this.updated_at = updatedAt;
		this.skillset=skillset;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + first_name + ", lastName=" + last_name + ", email=" + email
				+ ", phone=" + phone + ", gender=" + gender + ", dob=" + dob + ", age=" + age + ", joiningDate="
				+ joining_date + ", experienceYears=" + experience_years + ", salary=" + salary + ", role=" + role
				+ ", department=" + department + ", city=" + city + ", state=" + state + ", country=" + country
				+ ", status=" + status + ", createdAt=" + created_at + ", updatedAt=" + updated_at +", Skillset=" +skillset+"]";
	}
	
}
