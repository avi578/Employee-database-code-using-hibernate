package Employee_Operation;



public class Run_App {

	public static void main(String[] args) {
		EMPLOYEE_OPERATION e=new EMPLOYEE_OPERATION();;
		//e.getAllEmployee();
		//e.getEmployeeById(4);
		//e.getEmployeeByName("jane");
		//e.getEmployeeListWhoseNameStartsWith("m");
		//e.getEmployeeNameAndSalary();
		//e.getMaxSalary();
		//e.getSalaryBetweenGivenRange(60000,80000);
		//e.getEmployeeListByRole("Tester");
		//e.getEmployeeListByRoleAndSalary("developer",80000);
		//e.getTotalSalaryOfGivanRole("developer");
		//e.getEmployeeByDepartment("IT");
		//e.getEmployeeByExperience(9.0, 11.0);
		// e.getEmployeeWithHighestSalary();
		//e.getHighestPaidEmployee();
		//e.getLowestPaidEmployee();
		//e.getAverageSalaryOfDepartment("IT");
		//e.getTotalNumberOfEmployees();
		//e.getEmployeeByCity("Noida");
		//e.getEmployeeBySkillSet("java");
		//e.getSalaryDistributionByDepartment("IT");
		//e.getEmployeeCountByRole("HR Manager");
		//e.getEmployeeByAgeRange(20, 30);
	}

}
