package Employee_Operation;

import java.util.List;

import javax.crypto.Cipher;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.PropertyProjection;
import org.hibernate.criterion.Restrictions;
import java.time.LocalDate;
public class EMPLOYEE_OPERATION {
	SessionFactory sessionFactory=new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Employee.class).buildSessionFactory();
	Session openSession = sessionFactory.openSession();
	
	
	public void getAllEmployee() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		List<Employee> empList=criteria.list();
		System.out.println("METHOD:-->getAllEmployee()............");
		for(Employee e:empList) {
			System.out.println(e);
		}
	}
	public void getEmployeeById(long id) {
		Employee emp = (Employee)openSession.get(Employee.class, id);
		System.out.println("METHOD:-->getEmployeeById()............");

		System.out.println(emp+" ");
	}
	public void getEmployeeByName(String nm) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("first_name",nm));
		List<Employee > list = criteria.list();
		System.out.println("METHOD:-->getEmployeeByName()............");

		for(Employee e:list) {
			System.out.println(e+" ");
		}
	}
	public void getEmployeeListWhoseNameStartsWith(String nm) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.like("first_name", nm + "%"));
		List<Employee> list = criteria.list();
		System.out.println("METHOD:-->getEmployeeListWhoseNameStartsWith()............");
		for(Employee e:list) {
			System.out.println(e+" ");
		}
	}
	public void getEmployeeNameAndSalary() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		PropertyProjection p1 = Projections.property("first_name");
		PropertyProjection p2 = Projections.property("salary");
		ProjectionList p3 = Projections.projectionList();
		p3.add(p1);
		p3.add(p2);
		criteria.setProjection(p3);
		List<Object []> list = criteria.list();
		System.out.println("METHOD:-->getEmployeeNameAndSalary()............");
		for(Object e[]:list) {
			for(Object r:e) {
				System.out.print(" "+r);
			}
			System.out.println();
		}
	}
	public void getMaxSalary() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.setProjection(Projections.max("salary"));
		List list = criteria.list();
		System.out.println("Maximum Salary is :"+list);
	}
	public void getSalaryBetweenGivenRange(double Start,double End) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.between("salary", Start, End));
		List<Employee > list = criteria.list();
		System.out.println("METHOD:-->getSalaryBetweenGivenRange()............");
		for(Employee e:list) {
			System.out.println(e+" ");
		}
	}
	
	public void getEmployeeListByRole(String role) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("role", role));
		List<Employee> list = criteria.list();
		for(Employee e:list) {
			System.out.println(e+" ");
		}
	}
	public void getEmployeeListByRoleAndSalary(String role,double salary) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("role", role));
		criteria.add(Restrictions.eq("salary", salary));
		List<Employee> list = criteria.list();
		for(Employee emp:list) {
			System.out.println(emp+"\n");
		}
	}
	public void getTotalSalaryOfGivanRole(String role) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.setProjection(Projections.sum("salary"));
		criteria.add(Restrictions.eqOrIsNull("role", role));
		List list = criteria.list();
		System.out.println("Total salary of "+role+" is:"+list);
	}
	
	public void getEmployeeByDepartment(String departmentname) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("department",departmentname));
		List<Employee> list = criteria.list();
		for(Employee e:list) {
			System.out.println(e);
		}
	}
	public void getEmployeeByExperience(double minExperience,double maxExperience) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.between("experience_years",minExperience , maxExperience));
		List<Employee > list = criteria.list();
		for(Employee e:list) {
			System.out.println(e+" ");
		}
	}
	public void getEmployeeJoinedAfterDate(LocalDate dat) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.gt("joining_date",dat));
		List<Employee> list=criteria.list();
		for(Employee e:list) {
			System.out.println(e);
		}
	}
	
	public void getEmployeeWithHighestSalary() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		Criteria criteria2 = openSession.createCriteria(Employee.class);
		criteria2.setProjection(Projections.max("salary"));
		List sal = criteria2.list();
		double salar=(double)sal.get(0);
		System.out.println(salar);
		criteria.add(Restrictions.eq("salary",salar));
		List<Employee> list2 = criteria.list();
		for(Employee e:list2) {
			System.out.println(e);
		}
	}
//	public void getEmployeeSortedBySalary() {
//		Criteria criteria = openSession.createCriteria(Employee.class);
//		criteria.add(Projections.)
//	}
	public void getHighestPaidEmployee() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		Criteria criteria2 = openSession.createCriteria(Employee.class);
		criteria2.setProjection(Projections.max("salary"));
		List sal = criteria2.list();
		double salar=(double)sal.get(0);
		System.out.println(salar);
		criteria.add(Restrictions.eq("salary",salar));
		List<Employee> list2 = criteria.list();
		for(Employee e:list2) {
			System.out.println(e);
		}
	}
	public void getLowestPaidEmployee() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		Criteria criteria2 = openSession.createCriteria(Employee.class);
		criteria2.setProjection(Projections.min("salary"));
		List sal = criteria2.list();
		double salar=(double)sal.get(0);
		System.out.println(salar);
		criteria.add(Restrictions.eq("salary",salar));
		List<Employee> list2 = criteria.list();
		for(Employee e:list2) {
			System.out.println(e);
		}
	}
	public void getAverageSalaryOfDepartment(String string) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("department",string));
		criteria.setProjection(Projections.avg("salary"));
		List<Employee> list = criteria.list();
		System.out.println("Average Salary of "+string+" Department is:"+list);
	}
	public void getTotalNumberOfEmployees() {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.setProjection(Projections.count("id"));
		List list = criteria.list();
		System.out.println("Total Numbers of employees are:"+list);
	}
	public void getEmployeeByCity(String city) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("city", city));
		List<Employee > list = criteria.list();
		for(Employee e:list) {
			System.out.println(e);
		}
	}
	public void getEmployeeBySkillSet(String skillset) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("skillset", skillset));
		List<Employee > list = criteria.list();
		for(Employee e:list) {
			System.out.println(e);
		}
	}
	public void getSalaryDistributionByDepartment(String dept) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("department", dept));
		PropertyProjection p1 = Projections.property("department");
		PropertyProjection p2 = Projections.property("salary");
		ProjectionList p3 = Projections.projectionList();
		p3.add(p1);
		p3.add(p2);
		criteria.setProjection(p3);
		List<Object[]> list = criteria.list();
		for(Object row[]:list) {
			for(Object col:row) {
				System.out.print(col+"-->");
			}
			System.out.println();
		}
	}
	
	public void getEmployeeCountByRole(String role) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.eq("role", role));
		criteria.setProjection(Projections.count("role"));
		List list = criteria.list();
		System.out.println("The total count of employees are in role of "+role+" is:"+list);
	}
	public void getEmployeeByAgeRange(int  minAge,int maxAge) {
		Criteria criteria = openSession.createCriteria(Employee.class);
		criteria.add(Restrictions.between("age", minAge, maxAge));
		List<Employee> list = criteria.list();
		for(Employee e:list) {
			System.out.println(e);
		}
	}
	
}



